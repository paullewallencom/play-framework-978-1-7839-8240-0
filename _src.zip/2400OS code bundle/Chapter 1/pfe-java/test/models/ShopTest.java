package models;

import org.junit.Test;

import static org.junit.Assert.fail;

public class ShopTest {

    @Test
    public void addItem() {
        fail();
    }

}
